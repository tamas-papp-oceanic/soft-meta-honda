<style type="text/css">
	.st0{fill:none;}
	.st1{fill:#FFFFFF;}
</style>

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
	x="0px" y="0px" viewBox="0 0 250 250" width="100%" height="100%" xml:space="preserve">
	<g>
		<rect x="0" class="st0" width="250" height="250"/>
		<path class="st1" d="M228,109l8.8-8.8l-10.3-10.3L141,115.3l-9.2-9.2h-28.1v-9.1h13.9V84.5H77v12.4h14.2v9.1h-27v-8.5L15.9,77.7
			l-11,35.7l47,17.4v39.4h109.4l54.1-64.1l7.6-2.3L228,109z M51.9,117.6l-31.7-11.7l3.6-11.5l28.2,11.5V117.6z M155.5,157.8H64.3
			v-39.4h62.3l10.8,10.8l56.3-16.7L155.5,157.8z"/>
		<path class="st1" d="M230.9,128.6c-3.6,0-6.6,17.5-6.6,21.2c0,3.6,2.9,6.6,6.6,6.6c3.6,0,6.6-2.9,6.6-6.6
			C237.5,146.2,234.6,128.6,230.9,128.6z"/>
	</g>
</svg>
