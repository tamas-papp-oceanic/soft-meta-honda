<style type="text/css">
	.st0{fill:none;}
	.st1{fill:#FFFFFF;}
</style>

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
	x="0px" y="0px" viewBox="0 0 250 250" width="100%" height="100%" xml:space="preserve">
	<g>
		<rect class="st0" width="250" height="250"/>
		<path class="st1" d="M203.9,59.9h-34.7V78H80.5V59.9H45.8V78H14.2v128.6h221.7V78h-32V59.9z M224.7,89.1v106.3H25.3V89.1H224.7z"/>
		<rect x="40.9" y="123.9" class="st1" width="41" height="9.7"/>
		<polygon class="st1" points="183,149.2 192.8,149.2 192.8,133.6 208.4,133.6 208.4,123.9 192.8,123.9 192.8,108.2 183,108.2
			183,123.9 167.4,123.9 167.4,133.6 183,133.6 	"/>
	</g>
</svg>
