<style type="text/css">
	.st0{fill:none;}
	.st1{fill:#FFFFFF;}
</style>

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
	x="0px" y="0px" viewBox="0 0 250 250" width="100%" height="100%" xml:space="preserve">
	<g>
		<rect class="st0" width="250" height="250"/>
		<ellipse transform="matrix(0.9732 -0.2298 0.2298 0.9732 -38.552 33.796)" class="st1" cx="125.9" cy="182.5" rx="10.7" ry="10.7"/>
		<path class="st1" d="M112,99.7c0,9.6,6.2,53.2,6.9,60.1s6.9,6.7,6.9,6.7s6.2,0.2,6.9-6.7s6.9-50.5,6.9-60.1s-8.8-11.9-13.9-11.9
			C120.7,87.8,112,90.1,112,99.7z"/>
		<path class="st1" d="M132.9,37c-1.4-2.5-4.2-4.1-7-4.1c-2.9,0-5.6,1.6-7.1,4.1L21.2,206.1c-1.4,2.5-1.4,5.6,0,8.1
			c1.4,2.5,4.2,4.1,7.1,4.1h195.2c2.9,0,5.6-1.6,7-4.1c1.4-2.5,1.4-5.6,0-8.1L132.9,37z M33.3,207.2L125.9,47l92.5,160.3H33.3z"/>
	</g>
</svg>
