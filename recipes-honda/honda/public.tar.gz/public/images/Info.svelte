<style type="text/css">
	.st0{fill:black;}
</style>

<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
	x="0px" y="0px" viewBox="0 0 250 250" width="100%" height="100%" xml:space="preserve">
	<path class="st0" d="M125,223c-54,0-98-44-98-98c0-54,44-98,98-98c54,0,98,44,98,98C223,179,179,223,125,223z M125,38
		c-48,0-87,39-87,87c0,48,39,87,87,87c48,0,87-39,87-87C212,77,173,38,125,38z"/>
	<path class="st0" d="M129.2,60.7c3.6,0,5.4,1.8,5.4,5.4v10.5c0,3.6-1.8,5.4-5.4,5.4h-8.3c-3.6,0-5.4-1.8-5.4-5.4V66
		c0-3.6,1.8-5.4,5.4-5.4H129.2z M133.8,99.3v90h-17.5v-90H133.8z"/>
</svg>
