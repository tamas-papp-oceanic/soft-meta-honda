<script>
  import { fade } from "svelte/transition";
</script>

<style type="text/css">
  .st1 {fill: #ff0000;}
  .st2 {fill: none;}
</style>

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
  x="0px" y="0px" viewBox="0 0 24.5 59.3"height="100%" xml:space="preserve">
  <g id="Widgets">
    <path class="st1" d="M 6.8,39.1 C 4.3,36.6 2.9,33.3 2.9,29.7 2.9,26.2 4.3,22.8 6.8,20.3 L 24.5,0 H 23.9 L 4.1,19.9 C 1.4,22.5 0,26 0,29.7 c 0,3.7 1.4,7.2 4.1,9.8 l 19.8,19.8 h 0.6 z" />
    <rect class="st2" width="24.5" height="59.3" x="0" y="0" />
  </g>
</svg>
