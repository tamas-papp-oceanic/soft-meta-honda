<script>
  export let fill = "none";
  export let data = [];
</script>

<style lang="scss">
	.icon {
    width: 48px;
    height: 48px;
  }
</style>

<svg version="1.1" x="0" y="0" width="100%" height="100%" fill="{fill}" xmlns="http://www.w3.org/2000/svg"
  xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 48 48" class="icon">
  {#each data as item}
    <path d="{item}" />
  {/each}
</svg>
