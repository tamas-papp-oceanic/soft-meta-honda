<script>
  import { fade } from "svelte/transition";
</script>

<style type="text/css">
  .st1 {fill: #ff0000;}
  .st2 {fill: none;}
</style>

<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
  x="0px" y="0px" viewBox="0 0 24.5 59.3" height="100%" xml:space="preserve">
  <g id="Widgets">
    <path class="st1" d="m 17.7,39.166047 c 2.5,-2.504223 3.9,-5.809797 3.9,-9.415878 0,-3.505912 -1.4,-6.911655 -3.9,-9.415878 L 0,0 h 0.6 l 19.8,19.833446 c 2.6,2.604392 4.1,6.110304 4.1,9.816554 0,3.70625 -1.4,7.212162 -4.1,9.816554 L 0.6,59.3 H 0 Z" />
    <rect class="st2" width="24.5" height="59.3" x="0" y="0" />
  </g>
</svg>
