self.importScripts('glue.js');

const dataStates = {
	valid: 0,
  nodata: 1,
	error: 2,
	reserved: 2,
  timed: 4
}

const states = {
	ready: 0,
	wait: 1,
	done: 2
}

let socket;
let auth = false;
let queue = [];
let token = "";

onmessage = function(e) {
	if (typeof e.data.function !== "undefied") {
		switch (e.data.function) {
			case "open":
				open(e.data.data.address);
			  break;
			case "close":
				socket.close();
			  break;
			case "subscribe":
				subscribe(e.data.data.item);
			  break;
			case "unsubscribe":
				unsubscribe(e.data.data.item);
			  break;
			case "send":
				const { route, field, source } = e.data.data;
				send(route, field, source);
				break;
			case "token":
				setToken(e.data.data.token);
				break;
		}
	}
}

function ID() {
	return "WS" + Date.now();
}

function queueHandle() {
	if (queue.length > 0) {
		if (queue[0].state == states.ready) {
			if (auth || (!auth && (queue[0].data.method == "authorize"))) {
					queue[0].data.id = ID();
					socket.send(JSON.stringify(queue[0].data));
					queue[0].state = states.wait;
			}
		} else if (queue[0].state == states.wait) {
			if ((Date.now() - parseInt(queue[0].data.id.substring(2))) > 250) {
				queue.shift();
			}
		} else {
			queue.shift();
		}
	}
}

function splitRoute(route) {
	let tmp = route.split("/");
	let ret = {
		module: tmp[1],
		kind: tmp[2],
		bus: null,
		selector: null,
		group: null,
		instance: null,
		pgn: null,
		function: null,
		command: null,
		field: null
	};
	if (tmp.length > 2) {
		if (tmp[2] == "data") {
			ret.bus = parseInt(tmp[3]);
			ret.selector = tmp[4];
			switch (tmp[4]) {
				case "by_instance":
					ret.instance = parseInt(tmp[5]);
					ret.pgn = parseInt(tmp[6]);
					if (tmp.length > 7) {
						ret.field = parseInt(tmp[7]);
					}
					break;
				case "by_fluid_instance":
					ret.group = parseInt(tmp[5]);
					ret.instance = parseInt(tmp[6]);
					ret.pgn = parseInt(tmp[7]);
					if (tmp.length > 8) {
						ret.field = parseInt(tmp[8]);
					}
					break;
				case "by_dataid":
					ret.pgn = parseInt(tmp[5]);
					if (tmp.length > 6) {
						ret.field = parseInt(tmp[6]);
					}
					break;
				case "by_function":
					ret.pgn = parseInt(tmp[5]);
					ret.function = parseInt(tmp[6]);
					if (tmp.length > 7) {
						ret.field = parseInt(tmp[7]);
					}
					break;
				case "by_fluid_function":
					ret.group = parseInt(tmp[5]);
					ret.function = parseInt(tmp[6]);
					ret.instance = parseInt(tmp[7]);
					ret.pgn = parseInt(tmp[8]);
					if (tmp.length > 9) {
						ret.field = parseInt(tmp[9]);
					}
					break;
				case "by_zone":
					ret.pgn = parseInt(tmp[5]);
					ret.function = parseInt(tmp[6]);
					ret.group = parseInt(tmp[7]);
					if (tmp.length > 8) {
						ret.field = parseInt(tmp[8]);
					}
					break;
			}
		}
	}
	return ret;
}

function setToken(tok) {
	token = tok;
}

function open(addr) {
	socket = glue(addr);
	let int;

	socket.on("connected", function() {
		let itm = {method: "authorize", data: token}
		queue.unshift({data: itm, state: states.ready});
		int = setInterval(() => { queueHandle(); }, 10);
	});

	socket.onMessage(function(msg) {
	  let obj = JSON.parse(msg);
		if (obj.hasOwnProperty("id") && obj.hasOwnProperty("status") && (obj.status == 200)) {
			if (queue.length > 0) {
				if ((queue[0].state == states.wait) && (queue[0].data.id == obj.id)) {
					if (queue[0].data.method == "authorize") {
						let dat = JSON.parse(atob(obj.data));
			      if (dat.Access == token) {
							auth = true;
							queue[0].state = states.done;
			      }
					} else {
						if (auth) {
							queue[0].state = states.done;
						}
					}
				}
			}
		} else {
			if (!obj.hasOwnProperty("route")) {
				return;
			}
			let route = obj.route;
			if (!obj.hasOwnProperty("data")) {
				return;
			}
      let dat = JSON.parse(obj.data);
			let src = 0xFF;
			if (dat.hasOwnProperty("CanID")) {
				src = dat.CanID.Src;
			}
			let spl = splitRoute(route)
			if ((spl.module == "system") && (spl.kind == "time")) {
				self.postMessage({ function: "time", data: { route: route, value: dat }});
			} else if (spl.module == "alarmpro") {
				self.postMessage({ function: "alarm", data: { route: route, value: dat }});
			} else if (spl.field != null) {
				if ((dat.Fields.length > 0) && (dat.Fields[0].State != dataStates.nodata)) {
					let val = dat.Fields[0].Value;
					if ((dat.Fields[0].Type == "time") && (val.slice(-1) == "Z")) {
						val = val.slice(0, -1);
					}
					self.postMessage({ function: "data", data: {
						route: route, state: dat.Fields[0].State, value: val,
						unit: dat.Fields[0].Unit, source: src
					}});
				}
			} else {
				let out = []
        for (let i in dat.Fields) {
					if (dat.Fields[i].State != dataStates.nodata) {
						let val = dat.Fields[i].Value;
						if ((dat.Fields[i].Type == "time") && (val.slice(-1) == "Z")) {
							val = val.slice(0, -1);
						}
						out.push({
							route: route + "/" + dat.Fields[i].Field, state: dat.Fields[i].State,
							value: val, unit: dat.Fields[i].Unit, source: src
						});
					}
				}
				if (out.length > 0) {
					self.postMessage({ function: "data", data: {
						route: route, state: out[0].state, value: out, source: src
					}});
				}
			}
		}
	});

	socket.on("disconnected", function() {
		clearInterval(int);
		int = null;
	});

	socket.on("reconnecting", function() {
	});
}

function subscribe(itm) {
	queue.push({data: itm, state: states.ready});
}

function unsubscribe(itm) {
	queue.push({data: itm, state: states.ready});
}

function send(route, fld, src) {
	let spl = splitRoute(route);
	let stm = Date.now() * 1000;
	let dat = {
		RawData: ArrayBuffer,
		Fields:  [],
		Stamp: stm
	};
	for (let i in fld) {
		// Add data value
		dat.Fields.push(fld[i]);
	}
	if ((spl.module == "nmea2000") || (spl.module == "j1939")) {
		let pri = 3
		let dlc = 8
		let pdu = 2
		switch (spl.pgn) {
			case 59904:
			case 126720:
				pdu = 1
				break;
		}
		dat.CanID = {
			Pgn: spl.pgn, Dst: src, Ext: true, Rtr: false, Err: false, Pri: pri, Pdu: pdu,
			Dlc: dlc
		};
	} else if (spl.module == "hondapro") {
		dat.HondaID = {DataID: spl.pgn, Function: spl.function};
	}
	let itm = {
		method: "put",
		route: route,
		data: JSON.stringify(dat)
	};
	queue.push({data: itm, state: states.ready});
}
